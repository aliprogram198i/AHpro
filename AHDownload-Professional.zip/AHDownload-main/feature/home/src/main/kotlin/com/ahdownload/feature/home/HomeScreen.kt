package com.ahdownload.feature.home

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.BugReport
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.ContentPaste
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.HighQuality
import androidx.compose.material.icons.rounded.Link
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.PlayCircle
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Videocam
import androidx.compose.material.icons.rounded.AccountCircle
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.ahdownload.core.common.DiagnosticLevel
import com.ahdownload.core.common.DiagnosticLogger
import com.ahdownload.core.designsystem.AHGradientPrimaryButton
import com.ahdownload.core.designsystem.AHStatusPill
import com.ahdownload.domain.model.MediaKind
import com.ahdownload.domain.resolver.MediaCandidate
import com.ahdownload.domain.resolver.MediaContainer

@Composable
fun HomeRoute(
    initialUrl: String? = null,
    onDownloadRequested: suspend (MediaCandidate, String?) -> Boolean,
    logger: DiagnosticLogger,
    onOpenDiagnostics: () -> Unit,
    onOpenYouTubeSession: () -> Unit,
    onOpenSettings: () -> Unit,
) {
    val context = LocalContext.current
    val factory = remember(onDownloadRequested, logger, context) {
        HomeViewModel.Factory(onDownloadRequested, logger, context)
    }
    val viewModel: HomeViewModel = viewModel(factory = factory)
    val state by viewModel.uiState.collectAsStateWithLifecycle()

    LaunchedEffect(initialUrl) {
        initialUrl?.takeIf { it.isNotBlank() }?.let(viewModel::onUrlChanged)
    }

    HomeScreen(
        state = state,
        logger = logger,
        onUrlChanged = viewModel::onUrlChanged,
        onAnalyze = viewModel::analyze,
        onSelectCandidate = viewModel::selectCandidate,
        onDownload = viewModel::downloadSelected,
        onOpenDiagnostics = onOpenDiagnostics,
        onOpenYouTubeSession = onOpenYouTubeSession,
        onOpenSettings = onOpenSettings,
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun HomeScreen(
    state: HomeUiState,
    logger: DiagnosticLogger,
    onUrlChanged: (String) -> Unit,
    onAnalyze: () -> Unit,
    onSelectCandidate: (String) -> Unit,
    onDownload: () -> Unit,
    onOpenDiagnostics: () -> Unit,
    onOpenYouTubeSession: () -> Unit,
    onOpenSettings: () -> Unit,
) {
    val candidates = state.resolution?.candidates.orEmpty()
    val recommendedCandidate = candidates
        .sortedWith(
            compareByDescending<MediaCandidate> { it.format.kind == MediaKind.Video && it.format.hasAudio }
                .thenByDescending { val height = it.format.height ?: 0; if (it.format.kind == MediaKind.Video && height in 1..1080) 1 else 0 }
                .thenByDescending { if (it.format.kind == MediaKind.Video) it.format.height ?: 0 else 0 }
                .thenByDescending { it.format.hasAudio }
                .thenByDescending { it.format.bitrateKbps ?: 0 },
        )
        .firstOrNull()

    val videoCandidates = candidates
        .filter { it.format.kind == MediaKind.Video && it.id != recommendedCandidate?.id }
        .sortedWith(
            compareByDescending<MediaCandidate> { it.format.hasAudio }
                .thenByDescending { it.format.height ?: 0 }
                .thenByDescending { it.format.bitrateKbps ?: 0 },
        )
        .take(8)

    val audioCandidates = candidates
        .filter { it.format.kind == MediaKind.Audio }
        .sortedByDescending { it.format.bitrateKbps ?: 0 }
        .take(4)

    val clipboard = LocalClipboardManager.current

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            "AHDownload",
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                        )
                        Text(
                            "Smart Media Downloader",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.95f),
                ),
                actions = {
                    IconButton(onClick = onOpenSettings) {
                        Icon(Icons.Rounded.Settings, contentDescription = "الإعدادات")
                    }
                    IconButton(onClick = onOpenYouTubeSession) {
                        Icon(Icons.Rounded.AccountCircle, contentDescription = "جلسة YouTube")
                    }
                    IconButton(onClick = onOpenDiagnostics) {
                        Icon(Icons.Rounded.BugReport, contentDescription = "التشخيص")
                    }
                },
            )
        },
        containerColor = MaterialTheme.colorScheme.background,
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            // Hero / Input Section
            item {
                HeroInputCard(
                    url = state.url,
                    analyzing = state.analyzing,
                    resolving = state.resolving,
                    onUrlChanged = onUrlChanged,
                    onAnalyze = onAnalyze,
                    onPaste = {
                        clipboard.getText()?.text?.let { onUrlChanged(it) }
                    },
                )
            }

            // Loading state
            if (state.analyzing || state.resolving) {
                item {
                    LoadingCard(
                        message = if (state.analyzing) "جارٍ تحليل الرابط..." else "جارٍ استخراج الجودات المتاحة...",
                    )
                }
            }

            // Error
            state.error?.let { error ->
                item {
                    ErrorCard(message = error)
                }
            }

            // Success banner
            AnimatedVisibility(visible = state.downloadQueued) {
                item {
                    SuccessBanner()
                }
            }

            // Result header
            state.resolution?.let { resolution ->
                item {
                    ResultHeader(
                        title = resolution.title ?: "محتوى بدون عنوان",
                        durationMs = resolution.durationMs,
                        platform = state.result?.platform?.name ?: "Unknown",
                        candidateCount = candidates.size,
                    )
                }
            }

            // Recommended quality
            recommendedCandidate?.let { candidate ->
                item {
                    SectionLabel(
                        icon = Icons.Rounded.HighQuality,
                        text = "الجودة الموصى بها",
                        color = MaterialTheme.colorScheme.primary,
                    )
                }
                item {
                    QualityCard(
                        candidate = candidate,
                        selected = state.selectedCandidateId == candidate.id,
                        validating = state.validatingCandidateId == candidate.id,
                        isRecommended = true,
                        onSelect = { onSelectCandidate(candidate.id) },
                        onDownload = onDownload,
                    )
                }
            }

            // Video qualities
            if (videoCandidates.isNotEmpty()) {
                item {
                    SectionLabel(
                        icon = Icons.Rounded.Videocam,
                        text = "جودات الفيديو",
                    )
                }
                items(videoCandidates, key = { it.id }) { candidate ->
                    QualityCard(
                        candidate = candidate,
                        selected = state.selectedCandidateId == candidate.id,
                        validating = state.validatingCandidateId == candidate.id,
                        isRecommended = false,
                        onSelect = { onSelectCandidate(candidate.id) },
                        onDownload = onDownload,
                    )
                }
            }

            // Audio qualities
            if (audioCandidates.isNotEmpty()) {
                item {
                    SectionLabel(
                        icon = Icons.Rounded.MusicNote,
                        text = "صوت فقط",
                    )
                }
                items(audioCandidates, key = { it.id }) { candidate ->
                    QualityCard(
                        candidate = candidate,
                        selected = state.selectedCandidateId == candidate.id,
                        validating = state.validatingCandidateId == candidate.id,
                        isRecommended = false,
                        onSelect = { onSelectCandidate(candidate.id) },
                        onDownload = onDownload,
                    )
                }
            }

            // Empty result
            if (state.resolution != null && candidates.isEmpty() && !state.analyzing && !state.resolving) {
                item {
                    EmptyResultCard()
                }
            }

            // Bottom spacing
            item { Spacer(Modifier.height(32.dp)) }
        }
    }
}

@Composable
private fun HeroInputCard(
    url: String,
    analyzing: Boolean,
    resolving: Boolean,
    onUrlChanged: (String) -> Unit,
    onAnalyze: () -> Unit,
    onPaste: () -> Unit,
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.linearGradient(
                                listOf(
                                    MaterialTheme.colorScheme.primary,
                                    MaterialTheme.colorScheme.secondary,
                                ),
                            ),
                        ),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        Icons.Rounded.Link,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(22.dp),
                    )
                }
                Column {
                    Text(
                        "مركز التحميل الذكي",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    )
                    Text(
                        "YouTube · TikTok · Instagram · X",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }

            OutlinedTextField(
                value = url,
                onValueChange = onUrlChanged,
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                shape = RoundedCornerShape(16.dp),
                leadingIcon = {
                    Icon(Icons.Rounded.Link, contentDescription = null)
                },
                trailingIcon = {
                    IconButton(onClick = onPaste) {
                        Icon(Icons.Rounded.ContentPaste, contentDescription = "لصق")
                    }
                },
                label = { Text("الصق الرابط هنا") },
                placeholder = { Text("https://youtube.com/...") },
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Uri,
                    imeAction = ImeAction.Go,
                ),
                keyboardActions = KeyboardActions(onGo = { onAnalyze() }),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = MaterialTheme.colorScheme.primary,
                    unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f),
                ),
            )

            AHGradientPrimaryButton(
                text = when {
                    analyzing -> "جارٍ التحليل..."
                    resolving -> "جارٍ الاستخراج..."
                    else -> "تحليل واستخراج الجودات"
                },
                enabled = url.isNotBlank() && !analyzing && !resolving,
                onClick = onAnalyze,
            )
        }
    }
}

@Composable
private fun LoadingCard(message: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.08f),
        ),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            CircularProgressIndicator(
                modifier = Modifier.size(28.dp),
                strokeWidth = 3.dp,
                color = MaterialTheme.colorScheme.primary,
            )
            Text(
                message,
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurface,
            )
        }
    }
}

@Composable
private fun ErrorCard(message: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.7f),
        ),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Icon(
                Icons.Rounded.ErrorOutline,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.error,
            )
            Text(
                message,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onErrorContainer,
            )
        }
    }
}

@Composable
private fun SuccessBanner() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color(0xFF1B5E20).copy(alpha = 0.18f),
        ),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Icon(
                Icons.Rounded.CheckCircle,
                contentDescription = null,
                tint = Color(0xFF4CAF50),
            )
            Text(
                "تمت إضافة التحميل إلى القائمة بنجاح",
                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
            )
        }
    }
}

@Composable
private fun ResultHeader(
    title: String,
    durationMs: Long?,
    platform: String,
    candidateCount: Int,
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface,
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
    ) {
        Column(
            modifier = Modifier.padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Icon(
                    Icons.Rounded.PlayCircle,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(28.dp),
                )
                Text(
                    title,
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold),
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f),
                )
            }
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                AHStatusPill(platform)
                durationMs?.let { AHStatusPill(formatDuration(it)) }
                AHStatusPill("$candidateCount جودة")
            }
        }
    }
}

@Composable
private fun SectionLabel(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    text: String,
    color: Color = MaterialTheme.colorScheme.onSurfaceVariant,
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.padding(top = 4.dp),
    ) {
        Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(18.dp))
        Text(
            text,
            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold),
            color = color,
        )
    }
}

@Composable
private fun QualityCard(
    candidate: MediaCandidate,
    selected: Boolean,
    validating: Boolean,
    isRecommended: Boolean,
    onSelect: () -> Unit,
    onDownload: () -> Unit,
) {
    val format = candidate.format
    val borderColor = when {
        selected -> MaterialTheme.colorScheme.primary
        isRecommended -> MaterialTheme.colorScheme.primary.copy(alpha = 0.45f)
        else -> MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(
                width = if (selected || isRecommended) 1.5.dp else 1.dp,
                color = borderColor,
                shape = RoundedCornerShape(18.dp),
            )
            .clickable(onClick = onSelect),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (selected) {
                MaterialTheme.colorScheme.primary.copy(alpha = 0.08f)
            } else {
                MaterialTheme.colorScheme.surface
            },
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = if (selected) 4.dp else 0.dp),
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                // Quality badge
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(
                            if (isRecommended) {
                                Brush.horizontalGradient(
                                    listOf(
                                        MaterialTheme.colorScheme.primary,
                                        MaterialTheme.colorScheme.secondary,
                                    ),
                                )
                            } else {
                                Brush.horizontalGradient(
                                    listOf(
                                        MaterialTheme.colorScheme.surfaceVariant,
                                        MaterialTheme.colorScheme.surfaceVariant,
                                    ),
                                )
                            },
                        )
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                ) {
                    Text(
                        text = qualityLabel(format),
                        style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                        color = if (isRecommended) Color.White else MaterialTheme.colorScheme.onSurface,
                    )
                }

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = buildString {
                            append(containerLabel(format.container))
                            format.codec?.let { append(" · "); append(it) }
                        },
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
                    )
                    Text(
                        text = buildString {
                            if (format.hasVideo && format.hasAudio) append("فيديو + صوت")
                            else if (format.hasVideo) append("فيديو فقط")
                            else if (format.hasAudio) append("صوت فقط")
                            format.bitrateKbps?.let { append(" · "); append(it); append(" kbps") }
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }

                if (selected) {
                    Icon(
                        Icons.Rounded.CheckCircle,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                    )
                }
            }

            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                format.fileSizeBytes?.let {
                    AHStatusPill(formatBytes(it))
                }
                if (isRecommended) {
                    AHStatusPill("موصى بها", success = true)
                }
            }

            if (selected) {
                AHGradientPrimaryButton(
                    text = if (validating) "جارٍ التحقق..." else "تنزيل هذه الجودة",
                    enabled = !validating,
                    onClick = onDownload,
                )
            } else {
                FilledTonalButton(
                    onClick = onSelect,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                ) {
                    Icon(Icons.Rounded.Download, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("اختيار وتنزيل")
                }
            }
        }
    }
}

@Composable
private fun EmptyResultCard() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
        ),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Icon(
                Icons.Rounded.ErrorOutline,
                contentDescription = null,
                modifier = Modifier.size(40.dp),
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Text(
                "لم يتم العثور على وسائط قابلة للتنزيل",
                style = MaterialTheme.typography.titleMedium,
            )
            Text(
                "جرّب رابطاً آخر أو تأكد من أن المحتوى عام",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

private fun qualityLabel(format: com.ahdownload.domain.resolver.MediaFormat): String {
    val height = format.height
    return when {
        height != null && height >= 2160 -> "4K"
        height != null && height >= 1440 -> "1440p"
        height != null && height >= 1080 -> "1080p"
        height != null && height >= 720 -> "720p"
        height != null && height >= 480 -> "480p"
        height != null && height >= 360 -> "360p"
        height != null -> "${height}p"
        format.kind == MediaKind.Audio -> "Audio"
        else -> "Auto"
    }
}

private fun containerLabel(container: MediaContainer): String = when (container) {
    MediaContainer.Mp4 -> "MP4"
    MediaContainer.Webm -> "WebM"
    MediaContainer.Mkv -> "MKV"
    MediaContainer.Mov -> "MOV"
    MediaContainer.M4a -> "M4A"
    MediaContainer.Mp3 -> "MP3"
    MediaContainer.Aac -> "AAC"
    MediaContainer.Ogg -> "OGG"
    MediaContainer.Flac -> "FLAC"
    MediaContainer.ThreeGp -> "3GP"
    MediaContainer.Avi -> "AVI"
    MediaContainer.Unknown -> "Unknown"
}

private fun formatBytes(bytes: Long): String = when {
    bytes < 1024L -> "$bytes B"
    bytes < 1024L * 1024L -> "${bytes / 1024L} KB"
    bytes < 1024L * 1024L * 1024L -> "${bytes / (1024L * 1024L)} MB"
    else -> "${bytes / (1024L * 1024L * 1024L)} GB"
}

private fun formatDuration(durationMs: Long): String {
    val totalSeconds = (durationMs / 1000L).coerceAtLeast(0L)
    val minutes = totalSeconds / 60L
    val seconds = totalSeconds % 60L
    return "%d:%02d".format(minutes, seconds)
}
